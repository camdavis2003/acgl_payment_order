<?php

if (!defined('ABSPATH')) {
    exit;
}

function acgl_fms_kv_table_name() {
    global $wpdb;
    return $wpdb->prefix . ACGL_FMS_TABLE_KV;
}

function acgl_fms_db_install() {
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();
    $table = acgl_fms_kv_table_name();

    // Simple key/value store (values are stored as strings; typically JSON).
    $sql = "CREATE TABLE {$table} (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        k VARCHAR(191) NOT NULL,
        v LONGTEXT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY k (k)
    ) {$charset_collate};";

    dbDelta($sql);
}
