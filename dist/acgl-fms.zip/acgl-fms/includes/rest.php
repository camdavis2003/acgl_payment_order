<?php

if (!defined('ABSPATH')) {
    exit;
}

function acgl_fms_require_access() {
    return is_user_logged_in() && current_user_can(ACGL_FMS_CAP_ACCESS);
}

function acgl_fms_require_write() {
    return is_user_logged_in() && current_user_can(ACGL_FMS_CAP_WRITE);
}

function acgl_fms_sanitize_kv_key($key) {
    $k = is_string($key) ? $key : '';
    $k = trim($k);
    // Only allow characters we expect from localStorage keys.
    if ($k === '' || !preg_match('/^[A-Za-z0-9_\-\.]+$/', $k)) {
        return null;
    }
    return $k;
}

function acgl_fms_register_rest_routes() {
    register_rest_route('acgl-fms/v1', '/auth/login', [
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $request) {
            $username = strtolower(trim((string) $request->get_param('username')));
            $password = (string) $request->get_param('password');

            if ($username === '' || $password === '') {
                return new WP_REST_Response([ 'error' => 'missing_credentials' ], 400);
            }

            if (!acgl_fms_rate_limit_check($username)) {
                return new WP_REST_Response([ 'error' => 'rate_limited' ], 429);
            }

            $users = acgl_fms_load_users_from_kv();
            $user = acgl_fms_find_user_by_username($users, $username);
            if (!$user) {
                acgl_fms_rate_limit_bump($username);
                return new WP_REST_Response([ 'error' => 'invalid_credentials' ], 401);
            }

            if (!acgl_fms_verify_user_password($user, $password)) {
                acgl_fms_rate_limit_bump($username);
                return new WP_REST_Response([ 'error' => 'invalid_credentials' ], 401);
            }

            acgl_fms_rate_limit_clear($username);

            $perms = acgl_fms_normalize_permissions($user['permissions'] ?? []);
            $token = acgl_fms_issue_token($username, $perms);

            return [
                'ok' => true,
                'token' => $token,
                'user' => [
                    'username' => (string) ($user['username'] ?? $username),
                    'permissions' => $perms,
                ],
            ];
        },
    ]);

    register_rest_route('acgl-fms/v1', '/kv', [
        'methods'  => 'GET',
        'permission_callback' => function () {
            return acgl_fms_authorize_kv(null, null, false);
        },
        'callback' => function (WP_REST_Request $request) {
            global $wpdb;
            $table = acgl_fms_kv_table_name();

            $prefixes = $request->get_param('prefix');
            $items = [];

            if (is_array($prefixes) && count($prefixes) > 0) {
                // Multiple prefixes.
                $clauses = [];
                $params = [];
                foreach ($prefixes as $p) {
                    $p = is_string($p) ? $p : '';
                    $p = trim($p);
                    if ($p === '') continue;
                    $clauses[] = 'k LIKE %s';
                    $params[] = $wpdb->esc_like($p) . '%';
                }
                if (count($clauses) === 0) {
                    return [ 'items' => [] ];
                }
                $where = implode(' OR ', $clauses);
                $rows = $wpdb->get_results($wpdb->prepare("SELECT k, v FROM {$table} WHERE {$where}", ...$params), ARRAY_A);
                foreach ($rows as $r) {
                    $items[] = [ 'k' => $r['k'], 'v' => $r['v'] ];
                }
                return [ 'items' => $items ];
            }

            // Single prefix or no prefix.
            $prefix = $request->get_param('prefix');
            if (is_string($prefix) && trim($prefix) !== '') {
                $p = trim($prefix);
                $like = $wpdb->esc_like($p) . '%';
                $rows = $wpdb->get_results($wpdb->prepare("SELECT k, v FROM {$table} WHERE k LIKE %s", $like), ARRAY_A);
            } else {
                $rows = $wpdb->get_results("SELECT k, v FROM {$table}", ARRAY_A);
            }

            foreach ($rows as $r) {
                $items[] = [ 'k' => $r['k'], 'v' => $r['v'] ];
            }

            // If this is a bearer-token request, filter items to only what the token can access.
            $token = acgl_fms_get_bearer_token();
            $payload = $token ? acgl_fms_verify_token($token) : null;
            if ($payload) {
                $items = array_values(array_filter($items, function ($item) use ($payload) {
                    $k = is_array($item) ? (string) ($item['k'] ?? '') : '';
                    return $k !== '' && acgl_fms_token_allows_key($payload, $k, false);
                }));
            }

            return [ 'items' => $items ];
        },
    ]);

    register_rest_route('acgl-fms/v1', '/kv/(?P<key>[A-Za-z0-9_\-\.]+)', [
        [
            'methods'  => 'GET',
            'permission_callback' => function (WP_REST_Request $request) {
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) return false;
                return acgl_fms_authorize_kv($request, $key, false);
            },
            'callback' => function (WP_REST_Request $request) {
                global $wpdb;
                $table = acgl_fms_kv_table_name();
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) {
                    return new WP_REST_Response([ 'error' => 'invalid_key' ], 400);
                }

                $row = $wpdb->get_row($wpdb->prepare("SELECT v FROM {$table} WHERE k = %s", $key), ARRAY_A);
                if (!$row) {
                    return new WP_REST_Response([ 'k' => $key, 'v' => null ], 200);
                }
                return [ 'k' => $key, 'v' => $row['v'] ];
            },
        ],
        [
            'methods'  => 'POST',
            'permission_callback' => function (WP_REST_Request $request) {
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) return false;
                return acgl_fms_authorize_kv($request, $key, true);
            },
            'callback' => function (WP_REST_Request $request) {
                global $wpdb;
                $table = acgl_fms_kv_table_name();
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) {
                    return new WP_REST_Response([ 'error' => 'invalid_key' ], 400);
                }

                $value = $request->get_param('value');
                if (!is_string($value) && $value !== null) {
                    return new WP_REST_Response([ 'error' => 'invalid_value' ], 400);
                }

                $now = current_time('mysql');
                $wpdb->query(
                    $wpdb->prepare(
                        "INSERT INTO {$table} (k, v, updated_at) VALUES (%s, %s, %s)
                         ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = VALUES(updated_at)",
                        $key,
                        $value,
                        $now
                    )
                );

                return [ 'ok' => true, 'k' => $key ];
            },
        ],
        [
            'methods'  => 'DELETE',
            'permission_callback' => function (WP_REST_Request $request) {
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) return false;
                return acgl_fms_authorize_kv($request, $key, true);
            },
            'callback' => function (WP_REST_Request $request) {
                global $wpdb;
                $table = acgl_fms_kv_table_name();
                $key = acgl_fms_sanitize_kv_key($request['key']);
                if (!$key) {
                    return new WP_REST_Response([ 'error' => 'invalid_key' ], 400);
                }
                $wpdb->delete($table, [ 'k' => $key ], [ '%s' ]);
                return [ 'ok' => true, 'k' => $key ];
            },
        ],
    ]);
}
